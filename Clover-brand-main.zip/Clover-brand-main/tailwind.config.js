// tailwind.config.js
module.exports = {
    theme: {
      extend: {
        fontFamily: {
          sans: ['var(--font-sans)'],
        },
      },
    },
  }
  